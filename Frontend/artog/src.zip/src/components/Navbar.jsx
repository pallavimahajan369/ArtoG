import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const NavLogo = () => (
  <Link
    to="/"
    className="font-bangers text-5xl md:text-6xl text-orange-500 tracking-wider transition-all duration-300 hover:text-orange-400 hover:drop-shadow-[0_0_12px_#F97316]"
  >
    ArtoG
  </Link>
);

const Navbar = ({ isLoggedIn, setIsLoggedIn }) => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  // Scroll effect
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Gallery", path: "/gallery" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("role");
    setIsLoggedIn(false);
    toast.success("Logged out successfully!");
    navigate("/");
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? "bg-black/80 backdrop-blur-sm shadow-lg shadow-orange-500/10"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-24 md:h-28">
            {/* Logo */}
            <div className="flex-shrink-0">
              <NavLogo />
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-6">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className="text-gray-300 hover:text-orange-500 px-4 py-3 rounded-md text-lg md:text-xl font-semibold transition-colors duration-300"
                >
                  {item.name}
                </Link>
              ))}

              {/* Right Side Auth */}
              {!isLoggedIn ? (
                <Link
                  to="/login"
                  className="bg-orange-600 text-white px-5 py-3 rounded-md text-lg md:text-xl font-semibold hover:bg-orange-500 transition-all duration-300 shadow-md hover:shadow-lg hover:shadow-orange-500/50"
                >
                  Login
                </Link>
              ) : (
                <div className="relative">
                  <button
                    onClick={() => setShowDropdown(!showDropdown)}
                    className="flex items-center bg-gray-800 rounded-full p-2 hover:shadow-lg transition-shadow"
                  >
                    <img
                      src="https://i.pravatar.cc/40"
                      alt="Profile"
                      className="h-10 w-10 rounded-full"
                    />
                  </button>

                  {showDropdown && (
                    <div className="absolute right-0 mt-2 w-40 bg-gray-900 border border-gray-700 rounded-md shadow-lg py-1 z-50">
                      <Link
                        to="/profile"
                        className="block px-4 py-2 text-gray-300 hover:bg-orange-500 hover:text-white"
                      >
                        Profile
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="w-full text-left px-4 py-2 text-gray-300 hover:bg-red-600 hover:text-white"
                      >
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="-mr-2 flex md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                type="button"
                className="bg-gray-800 inline-flex items-center justify-center p-3 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
              >
                {!isOpen ? (
                  <svg
                    className="block h-7 w-7"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  </svg>
                ) : (
                  <svg
                    className="block h-7 w-7"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden bg-black/90" id="mobile-menu">
            <div className="px-2 pt-2 pb-3 space-y-2 sm:px-3">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className="text-gray-300 hover:text-orange-500 block px-4 py-3 rounded-md text-lg font-semibold transition-colors duration-300"
                >
                  {item.name}
                </Link>
              ))}

              {!isLoggedIn ? (
                <Link
                  to="/login"
                  className="bg-orange-600 text-white block px-4 py-3 mx-1 rounded-md text-lg font-semibold hover:bg-orange-500 transition-all duration-300"
                >
                  Login
                </Link>
              ) : (
                <>
                  <Link
                    to="/profile"
                    className="text-gray-300 block px-4 py-3 rounded-md text-lg font-semibold hover:bg-orange-500 hover:text-white"
                  >
                    Profile
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="w-full text-left text-gray-300 block px-4 py-3 rounded-md text-lg font-semibold hover:bg-red-600 hover:text-white"
                  >
                    Logout
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </nav>

      <ToastContainer position="top-right" newestOnTop />
    </>
  );
};

export default Navbar;
