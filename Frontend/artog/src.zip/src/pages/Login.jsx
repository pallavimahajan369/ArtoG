import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Footer from "../components/Footer";
import { loginUser } from "../api/authApi";
import { toast } from "react-toastify"; // ✅ Already imported in App/Navbar

const Login = ({ onLogin }) => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();

    try {
      const data = await loginUser({ email, password });

      // Store token & user info
      localStorage.setItem("token", data.token);
      localStorage.setItem("userId", data.userId);
      localStorage.setItem("role", data.role);

      // ✅ Update app state
      if (onLogin) onLogin(true);

      toast.success("Login successful!", { autoClose: 2000 });
      navigate("/"); // redirect home
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Login failed. Please try again.",
        { autoClose: 3000 }
      );
    }
  };

  return (
    <>
      <div className="min-h-screen flex items-center justify-center pt-24 pb-12 bg-black">
        <div className="max-w-md w-full mx-auto p-8 bg-gray-900/80 backdrop-blur-sm rounded-xl shadow-lg space-y-6 border border-gray-700">
          <div className="text-center">
            <h1 className="font-bangers text-5xl text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-300 tracking-wider">
              Welcome Back
            </h1>
            <p className="mt-2 text-gray-400">Sign in to continue to ArtoG.</p>
          </div>

          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Email */}
            <div>
              <label
                htmlFor="email"
                className="text-sm font-medium text-gray-300"
              >
                Email Address
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="mt-1 block w-full bg-gray-800 border border-gray-600 rounded-md py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                placeholder="you@example.com"
              />
            </div>

            {/* Password */}
            <div>
              <label
                htmlFor="password"
                className="text-sm font-medium text-gray-300"
              >
                Password
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="mt-1 block w-full bg-gray-800 border border-gray-600 rounded-md py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                placeholder="Your Password"
              />
            </div>

            {/* Remember Me + Forgot */}
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-500 rounded bg-gray-700"
                />
                <label
                  htmlFor="remember-me"
                  className="ml-2 block text-sm text-gray-400"
                >
                  Remember me
                </label>
              </div>
              <div className="text-sm">
                <a
                  href="#"
                  className="font-medium text-orange-500 hover:text-orange-400"
                >
                  Forgot your password?
                </a>
              </div>
            </div>

            {/* Submit */}
            <div>
              <button
                type="submit"
                className="w-full px-8 py-3 bg-orange-600 text-white font-bold rounded-lg shadow-2xl transform transition-all duration-300 hover:scale-105 hover:bg-orange-500 hover:shadow-orange-500/60 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-orange-500"
              >
                Sign In
              </button>
            </div>
          </form>

          <p className="text-center text-sm text-gray-400">
            Not a member?{" "}
            <Link
              to="/signup"
              className="font-medium text-orange-500 hover:text-orange-400"
            >
              Sign up now
            </Link>
          </p>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default Login;
